from flask import Flask, render_template, request, jsonify, send_from_directory
from process_video import WebcamProcessor
import os

app = Flask(__name__)
processor = WebcamProcessor()
OUTPUT_FOLDER = "outputs"
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

@app.route("/")
def index():
    return render_template("webcam.html")

@app.route("/start", methods=["POST"])
def start():
    processor.start()
    return jsonify({"status":"started"})

@app.route("/stop", methods=["POST"])
def stop():
    video_file, csv_file, avg_score = processor.stop()
    return jsonify({
        "status": "stopped",
        "video": os.path.basename(video_file),
        "csv": os.path.basename(csv_file),
        "avg_score": round(avg_score*100, 2)
    })

@app.route("/analyze_frame", methods=["POST"])
def analyze_frame():
    import cv2, numpy as np, base64
    data = request.get_json()
    frame_data = data["frame"].split(",")[1]
    frame_bytes = base64.b64decode(frame_data)
    np_arr = np.frombuffer(frame_bytes, np.uint8)
    frame = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
    annotated, score = processor.process_frame(frame)
    return jsonify({"score": score})

@app.route("/download/<path:filename>")
def download(filename):
    return send_from_directory(OUTPUT_FOLDER, filename, as_attachment=True)

if __name__ == "__main__":
    app.run(debug=True)







