import cv2
import dlib
import numpy as np
import os

class AttentionDetector:
    def __init__(self):
        self.detector = dlib.get_frontal_face_detector()
        model_path = "shape_predictor_68_face_landmarks.dat"
        if os.path.exists(model_path):
            self.predictor = dlib.shape_predictor(model_path)
            print("Dlib model loaded successfully.")
        else:
            raise FileNotFoundError(f"{model_path} not found. Download it to use the detector.")
        
        # 3D model points for head pose estimation
        self.model_points = np.array([
            (0.0, 0.0, 0.0),          # Nose tip
            (0.0, -330.0, -65.0),      # Chin
            (-225.0, 170.0, -135.0),   # Left eye left corner
            (225.0, 170.0, -135.0),    # Right eye right corner
            (-150.0, -150.0, -125.0),  # Left mouth corner
            (150.0, -150.0, -125.0)    # Right mouth corner
        ])

    def analyze(self, frame):
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = self.detector(gray, 0)
        scores = []
        annotated = frame.copy()

        for face in faces:
            shape = self.predictor(gray, face)
            landmarks = np.array([(shape.part(i).x, shape.part(i).y) for i in range(68)], dtype="double")

            image_points = np.array([
                landmarks[30],  # Nose tip
                landmarks[8],   # Chin
                landmarks[36],  # Left eye left corner
                landmarks[45],  # Right eye right corner
                landmarks[48],  # Left mouth corner
                landmarks[54],  # Right mouth corner
            ], dtype="double")

            size = frame.shape
            focal_length = size[1]
            center = (size[1]/2, size[0]/2)
            camera_matrix = np.array([
                [focal_length, 0, center[0]],
                [0, focal_length, center[1]],
                [0, 0, 1]
            ], dtype="double")
            dist_coeffs = np.zeros((4,1))

            success, rotation_vector, translation_vector = cv2.solvePnP(
                self.model_points, image_points, camera_matrix, dist_coeffs
            )

            if success:
                rvec_matrix, _ = cv2.Rodrigues(rotation_vector)
                proj_matrix = np.hstack((rvec_matrix, translation_vector))
                _, _, _, _, _, _, euler_angles = cv2.decomposeProjectionMatrix(proj_matrix)
                yaw = euler_angles[1,0]
                pitch = euler_angles[0,0]
                yaw_score = max(0, 1 - abs(yaw)/45)
                pitch_score = max(0, 1 - abs(pitch)/45)
                score = (yaw_score + pitch_score)/2
                scores.append(score)
                x1, y1, x2, y2 = face.left(), face.top(), face.right(), face.bottom()
                if score > 0.7:
                    status = f"Focused ({score:.2f})"
                    color = (0,255,0)
                elif score > 0.4:
                    status = f"Partial ({score:.2f})"
                    color = (0,255,255)
                else:
                    status = f"Distracted ({score:.2f})"
                    color = (0,0,255)

                cv2.rectangle(annotated, (x1,y1), (x2,y2), color, 2)
                cv2.putText(annotated, status, (x1, y1-10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
        if not scores:
            scores.append(0.0)
            cv2.putText(annotated, "No face detected", (50,50),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (200,200,200), 2)

        avg_score = float(np.mean(scores))
        return annotated, avg_score








