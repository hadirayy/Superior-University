import cv2
import pandas as pd
import os
import time
from detector import AttentionDetector

OUTPUT_FOLDER = "outputs"
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

class WebcamProcessor:
    def __init__(self):
        self.detector = AttentionDetector()
        self.cap = None
        self.frame_scores = []
        self.video_writer = None
        self.recording = False
        self.video_path = ""
        self.csv_path = ""

    def start(self):
        self.cap = cv2.VideoCapture(0)
        if not self.cap.isOpened():
            raise RuntimeError("Cannot open webcam")
        self.frame_scores = []
        self.recording = True
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        timestamp = int(time.time())
        self.video_path = os.path.join(OUTPUT_FOLDER, f"webcam_{timestamp}.mp4")
        fps = int(self.cap.get(cv2.CAP_PROP_FPS)) or 20
        width = int(self.cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(self.cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        self.video_writer = cv2.VideoWriter(self.video_path, fourcc, fps, (width, height))

        self.csv_path = os.path.join(OUTPUT_FOLDER, f"webcam_{timestamp}.csv")

    def process_frame(self, frame):
        annotated, score = self.detector.analyze(frame)
        if self.recording and self.video_writer:
            self.video_writer.write(annotated)
        self.frame_scores.append(score)
        return annotated, score

    def stop(self):
        self.recording = False
        if self.cap:
            self.cap.release()
        if self.video_writer:
            self.video_writer.release()
        df = pd.DataFrame({"Score": self.frame_scores})
        df.to_csv(self.csv_path, index=False)
        avg_score = float(sum(self.frame_scores)/len(self.frame_scores)) if self.frame_scores else 0.0
        return self.video_path, self.csv_path, avg_score



