import os
import pandas as pd
import numpy as np
from sentence_transformers import SentenceTransformer
import faiss
import pickle
from tqdm import tqdm

DATA_CSV = "qna.csv"
MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"
BATCH = 64
INDEX_FILE = "faiss_index.idx"
META_FILE = "meta.pkl"
EMB_FILE = "embeddings.npy"

def load_data(path):
    df = pd.read_csv(path, dtype=str).fillna("")
    if "question" not in df.columns or "answer" not in df.columns:
        raise ValueError("CSV must contain 'question' and 'answer' columns")
    if "id" not in df.columns:
        df.insert(0, "id", range(1, len(df)+1))
    return df

def embed_texts(model, texts, batch_size=64):
    out = []
    for i in tqdm(range(0, len(texts), batch_size), desc="Embedding"):
        batch = texts[i:i+batch_size]
        embs = model.encode(batch, convert_to_numpy=True, show_progress_bar=False)
        out.append(embs)
    return np.vstack(out)

def build_index(embeddings):
    faiss.normalize_L2(embeddings)
    d = embeddings.shape[1]
    index = faiss.IndexFlatIP(d)
    index.add(embeddings)
    return index

def main():
    os.makedirs("data", exist_ok=True)
    df = load_data(DATA_CSV)
    texts = (df["question"] + " " + df["answer"]).tolist()  

    print("Loading model:", MODEL_NAME)
    model = SentenceTransformer(MODEL_NAME)

    print("Computing embeddings...")
    embeddings = embed_texts(model, texts, batch_size=BATCH)

    print("Building FAISS index...")
    index = build_index(embeddings)

    print("Saving index and metadata...")
    faiss.write_index(index, INDEX_FILE)
    with open(META_FILE, "wb") as f:
        pickle.dump(df.to_dict(orient="records"), f)
    np.save(EMB_FILE, embeddings)
    print(f"Saved {INDEX_FILE}, {META_FILE}, {EMB_FILE}")
    print("Done. Items indexed:", len(df))

if __name__ == "__main__":
    main()

