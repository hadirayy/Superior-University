import faiss
import pickle
import numpy as np
from sentence_transformers import SentenceTransformer

INDEX_FILE = "faiss_index.idx"
META_FILE = "meta.pkl"
MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"

_model = None
_index = None
_meta = None

def load_resources():
    global _model, _index, _meta
    if _model is None:
        _model = SentenceTransformer(MODEL_NAME)
    if _index is None:
        _index = faiss.read_index(INDEX_FILE)
    if _meta is None:
        with open(META_FILE, "rb") as f:
            _meta = pickle.load(f)
    return _model, _index, _meta

def embed_query(text):
    model, _, _ = load_resources()
    v = model.encode([text], convert_to_numpy=True)
    faiss.normalize_L2(v)
    return v

def search(query, top_k=5):
    _, index, meta = load_resources()
    qv = embed_query(query)
    D, I = index.search(qv, top_k)
    results = []
    for score, idx in zip(D[0], I[0]):
        if idx < 0:
            continue
        item = meta[idx]
        results.append({
            "id": item.get("id"),
            "question": item.get("question"),
            "answer": item.get("answer"),
            "score": float(score) 
        })
    return results
