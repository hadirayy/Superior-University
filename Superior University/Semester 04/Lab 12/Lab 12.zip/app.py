
from flask import Flask, render_template, request, jsonify
from search_utils import search
from search_utils import load_resources

app = Flask(__name__)

load_resources()

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/api/search", methods=["POST"])
def api_search():
    data = request.json or {}
    query = data.get("query", "").strip()
    if not query:
        return jsonify({"error": "Empty query"}), 400
    top_k = int(data.get("top_k", 5))
    results = search(query, top_k=top_k)
    for r in results:
        r["score_pct"] = round((r["score"] + 1) / 2 * 100, 2)
    return jsonify({"query": query, "results": results})

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
