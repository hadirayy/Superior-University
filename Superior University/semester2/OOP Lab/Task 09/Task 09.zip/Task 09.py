import csv

class Document:
    def __init__(self,title,author):
        self.title=title
        self.author=author
    def display_info(self):
        print(f"Title:{self.title} Author:{self.author}")
class Book(Document):
    def __init__(self,title,author,genre,pages):
        super().__init__(title,author)
        self.genre=genre    
        self.pages=pages
        

    def display_info(self):
        print(f"Title:{self.title} Author:{self.author} Genre:{self.genre} Pages:{self.pages}")
class Article(Document):
    def __init__(self,title,author,journal,DOI):
        super().__init__(title,author)
        self.journal=journal
        self.DOI=DOI 
    def display_info(self):
        print(f"Title:{self.title} Author:{self.author} Journal:{self.journal}DOI{self.DOI}")
def save_to_csv(document,filename):
    with open(filename, mode='w',newline ='') as file:
        writer = csv.writer(file)
        writer.writerow(['Type','Title','Author','Genre','Pages','Journal','DOI'])
        for doc in document:
            if isinstance(doc, Book):
                writer.writerow(['Book',doc.title,doc.author,doc.genre,doc.pages,'',''])
            elif isinstance(doc, Article):
                writer.writerow(['Artical',doc.title,doc.author,'','',doc.journal,doc.DOI])
def load_from_csv(filename):
    document=[]
    with open(filename,mode='r') as file:
        reader = csv.reader(file)
        next(reader)
        for row in reader:
            doc_type=row[0]
            title  = row[1]
            author = row[2]
            genre  = row[3] if doc_type == 'Book' else None
            pages=int(row[4]) if doc_type =='Book' else None
            journal= row[5] if doc_type =='Article'else None
            doi    = row[6] if doc_type =='Article'else None
            if doc_type =='Book':
                document.append(Book(title,author,genre,pages))
            elif doc_type =='Article':
                document.append(Article(title,author,journal,doi))
    return document
book1=Book("Crepeers","Human","Reality",200)
book2=Book("Zombies","Karin baig","Factional",2022)
article1=Article("Human","Hadi","Experience",2006)
article2=Article("Life","Goku","Anime",2024)
print(book1.display_info())
print(book2.display_info())
print(article1.display_info())
print(article2.display_info())
document=[book1,book2,article1,article2]
save_to_csv(document,'document.csv')
load_from_document=load_from_csv('document.csv')
for doc in load_from_document:
    print(doc.display_info())
    



