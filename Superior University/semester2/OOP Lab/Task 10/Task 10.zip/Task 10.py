import csv
class Employee: 
    def __init__(self, name, age, salary): 
        self.__name = name   
        self.__age = age   
        self.__salary = salary  
 
    def display_info(self): 
        print("Name:", self.__name) 
        print("Age:", self.__age) 
        print("Salary:", self.__salary) 
 
    def get_name(self): 
        return self.__name 
 
    def get_age(self): 
        return self.__age 
 
    def get_salary(self): 
        return self.__salary 
 
    
    def set_name(self, name): 
        self.__name = name 
 
    def set_age(self, age): 
        self.__age = age 
 
    def set_salary(self, salary): 
        self.__salary = salary
class Manager(Employee): 
    def __init__(self, name, age, salary, department): 
        super().__init__(name, age, salary) 
        self.__department = department  
 
    def display_info(self): 
        super().display_info() 
        print("Department:", self.__department) 
 
   
    def get_department(self): 
        return self.__department 
 
    def set_department(self, department): 
        self.__department = department 

class Worker(Employee): 
    def __init__(self, name, age, salary, hours_worked): 
        super().__init__(name, age, salary) 
        self.__hours_worked = hours_worked   
 
    def display_info(self): 
        super().display_info() 
        print("Hours Worked:", self.__hours_worked) 
 

    def get_hours_worked(self): 
        return self.__hours_worked 
 
    def set_hours_worked(self, hours_worked): 
        self.__hours_worked = hours_worked
class FileHandler: 
    def save_employees(employees, filename): 
        with open(filename, mode='w', newline='') as file: 
            writer = csv.writer(file) 
            for employee in employees: 
                if isinstance(employee, Manager): 
                    writer.writerow([employee.get_name(), employee.get_age(), employee.get_salary(), employee.get_department(), '']) 
                elif isinstance(employee, Worker): 
                    writer.writerow([employee.get_name(), employee.get_age(), employee.get_salary(), '', employee.get_hours_worked()]) 
 
    def load_employees(filename): 
        employees = [] 
        with open(filename, mode='r') as file: 
            reader = csv.reader(file) 
            for row in reader: 
                name, age, salary, department, hours_worked = row 
                if department:
                    employees.append(Manager(name, age, salary, department)) 
                elif hours_worked: 
                    employees.append(Worker(name, age, salary, hours_worked)) 
        return employees 
 
def add_employee(employees): 
    employee_type = input("Enter employee type (manager/worker): ").strip().lower() 
    name = input("Enter name: ") 
    age = int(input("Enter age: ")) 
    salary = int(input("Enter salary: ")) 
    if employee_type == 'manager': 
        department = input("Enter department: ") 
        employees.append(Manager(name, age, salary, department)) 
    elif employee_type == 'worker': 
        hours_worked = int(input("Enter hours worked: ")) 
        employees.append(Worker(name, age, salary, hours_worked)) 
 
def display_employees(employees): 
    for employee in employees: 
        employee.display_info() 
        print('-' * 20) 
 
def update_employee(employees): 
    name = input("Enter name of employee to update: ") 
    for employee in employees: 
        if employee.get_name() == name: 
            attribute = input("Enter attribute to update name/age/salary/department/hours_worked): ").strip().lower() 
            if attribute == 'name': 
                employee.set_name(input("Enter new name: ")) 
            elif attribute == 'age': 
                employee.set_age(int(input("Enter new age: "))) 
            elif attribute == 'salary': 
                employee.set_salary(int(input("Enter new salary: "))) 
            elif attribute == 'department' and isinstance(employee, Manager): 
                employee.set_department(input("Enter new department: ")) 
            elif attribute == 'hours_worked' and isinstance(employee, Worker): 
                employee.set_hours_worked(int(input("Enter new hours worked: "))) 
            break 
 
def delete_employee(employees): 
    name = input("Enter name of employee to delete: ") 
    for i, employee in enumerate(employees): 
        if employee.get_name() == name:
            del employees[i] 
            break 
 
def main(): 
    filename = 'employees.csv' 
    employees = FileHandler.load_employees(filename) 
     
    while True: 
        print("1. Add Employee") 
        print("2. Display Employees") 
        print("3. Update Employee") 
        print("4. Delete Employee") 
        print("5. Save and Exit") 
         
        choice = int(input("Enter your choice: ")) 
         
        if choice == 1: 
            add_employee(employees) 
        elif choice == 2: 
            display_employees(employees) 
        elif choice == 3: 
            update_employee(employees) 
        elif choice == 4: 
            delete_employee(employees) 
        elif choice == 5: 
            FileHandler.save_employees(employees, filename) 
            break 
 
if __name__ == '__main__': 
    main()
